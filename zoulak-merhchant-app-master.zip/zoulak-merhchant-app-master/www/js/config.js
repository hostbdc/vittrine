
var krms_config ={					
    'ApiUrl':"http://zoulak.com/merchantapp/api",	           
	'DialogDefaultTitle':"zoulak merchant app",
	'pushNotificationSenderid':"600405925358",
	'APIHasKey':""
};